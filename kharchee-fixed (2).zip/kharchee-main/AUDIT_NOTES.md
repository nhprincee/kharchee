# Kharchee — local audit notes

This is a focused safety/security pass on the supplied source snapshot, not a claim that the app is production-ready.

## Changes made

- API rate limiting no longer trusts a client-supplied `X-Forwarded-For` value by default. `TRUST_PROXY_HOPS` is available for deployments that explicitly require a trusted reverse proxy.
- Periodically prunes stale rate-limit entries to reduce unbounded in-memory growth.
- Receipt OCR now validates the image MIME type, base64 format, and image size before forwarding data to Gemini; parsed vendor/summary lengths and amount range are bounded.
- Removed hard-coded personal UPI IDs and personal name/email defaults. Payment links/QRs require a configured UPI ID; recipient VPAs are no longer guessed from phone numbers or names.
- Onboarding makes it clear that Google sign-in is not connected and does not prefill a real person's profile details.
- NFC demo presets remain clearly marked as demos and do not auto-submit fabricated amounts.
- UTR references remain explicitly unverified; a 12-digit format alone is not treated as proof of payment.

## Verification status

- All 28 TypeScript/TSX files passed a TypeScript syntax-transpile check.
- `package.json` parsed as valid JSON.
- Full dependency installation, TypeScript type-check, and production build could not be completed in this environment because `npm install` timed out and dependencies/types were unavailable. Run `npm install`, `npm run lint`, and `npm run build` locally before deployment.

## Still required before launch

- Configure a production Gemini API key only in server-side environment secrets; never commit `.env`.
- Add a real payment provider and server-side webhook verification before selling Pro access.
- Review privacy policy, data deletion/export, hosting, HTTPS, rate limiting behind the production proxy, and Android/Play Store requirements.
- Run functional tests on mobile and desktop, including backups/imports, income/expense totals, OCR failures, and all UPI flows.
